#include "functions.h"

/*
Function Name: print_game_rules
Author: Elliot Small
Purpose: Print the Rules for "Craps"
Created: 9/25/24
Last Updated: 9/26/24
*/
void print_game_rules(void)
{
	printf("A player rolls two dice. Each die has six faces. These faces contain 1, 2, 3, 4, 5, and 6 spots. After the dice have come to rest, the sum of the spots on the two upward faces is calculated. If the sum is 7 or 11 on the first throw, the player wins. If the sum is 2, 3, or 12 on the first throw (called 'craps'), the player loses(i.e.the 'house' wins). If the sum is 4, 5, 6, 8, 9, or 10 on the first throw, then the sum becomes the player's 'point.' To win, you must continue rolling the dice until you 'make your point.' The player loses by rolling a 7 before making the point.");
}

/*
Function Name: 

Author: Elliot Small
Purpose: Prompts the User for a starting bank balance
Created 9/25/24
Last Updated: 9/25/24
Precondition: User has no balance
Postcondition: User has a balance
*/
double get_bank_balance(void)
{
	double balance = 0.0;
	printf("How much money you got?: ");
	scanf("%lf", &balance);
	return balance;
}
/*
Function Name: get_wager_amount
Author: Elliot Small
Purpose: Prompts the User for a wager
Created 9/25/24
Last Updated: 9/25/24
Precondition: User has a balance and currently hasn't given a wager
Postcondition: User has a wager
*/
double get_wager_amount(void)
{
	double wager = 0.0;
	printf("PLACE YOUR BETS!: ");
	scanf("%lf", &wager);
	return wager;
}
/*
Function Name: checkWagerAmount
Author: Elliot Small
Purpose: Checks to make sure that the user has the balance for the wager
Created 9/25/24
Last Updated: 9/25/24
Precondition: User has a balance and a wager
Postcondition: The wager that was given is a valid wager.
*/
int checkWagerAmount(double wager, double balance)
{
	if (wager < 0 || wager > balance)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}
/*
Function Name: roll_die
Author: Elliot Small
Purpose: "Rolls" a die by generating a random number 1-6
Created 9/25/24
Last Updated: 9/25/24
Precondition: The user has to roll the dice
Postcondition: The user now has a roll for one die
References: Referenced both GeeksForGeeks and ChatGPT to learn how to create the random number generator (Worked on this before O'Fallon taught us)
*/
int roll_die(void)
{
	static int seeded = 0; //Ensures seeding only happens once
	if (!seeded)
	{
		srand(time(NULL)); //Seed the number generator
		seeded = 1; //Marks as seeded
	}
	return (rand() % 6) + 1;
}
/*
Function Name: calculate_sum_dice
Author: Elliot Small
Purpose: calculates the sum of the two dice rolls
Created 9/25/24
Last Updated: 9/25/24
Precondition: The user has rolled both dice
Postcondition: The user has the total for both dice
*/
int calculate_sum_dice(int die1_value, int die2_value)
{
	return die1_value + die2_value;
}
/*
Function Name: is_win_loss_or_point
Author: Elliot Small
Purpose: Checks the users first roll result to see if they won, lost, or will keep rolling
Created 9/25/24
Last Updated: 9/25/24
Precondition: The user has rolled the dice
Postcondition: The user has either won, lost, or will keep rolling
*/
int is_win_loss_or_point(int sum_dice)
{
	if (sum_dice == 7 || sum_dice == 11)
	{
		return 1;
	}
	else if (sum_dice == 2 || sum_dice == 3 || sum_dice == 12)
	{
		return 0;
	}
	else 
	{
		return -1;
	}
}

int is_point_loss_or_neither(int sum_dice, int point_value)
{
	if (point_value == sum_dice)
	{
		//printf("YOU WON CONGRATS!");
		return 1;
	}
	else if (sum_dice == 7)
	{
		//printf("Better Luck Next Time! House wins!");
		return 0;
	}
	else
	{
		//printf("Roll Again!");
		return -1;
	}
}

double adjust_bank_balance(double bank_balance, double wager_amount, int add_or_subtract)
{
	if (add_or_subtract == 1)
	{
		return bank_balance + wager_amount;
	}
	else if (add_or_subtract == 0)
	{
		return bank_balance - wager_amount;
	}
	else
	{
		return bank_balance;
	}
}

void chatter_messages(int chatterType, int number_rolls, double initial_bank_balance, double current_bank_balance, int sum_dice, int win_loss_neither, int point)
{
	int chatter = chatterType;

	switch (chatter)
	{
	case 1:
		if (number_rolls == 0)
		{
			printf("OOOO FIRST ROLL GOOD LUCK!\n");
		}
		else if (number_rolls == 1)
		{
			printf("Let's see if you got it this time!\n");
		}
		else if (number_rolls >= 2 && number_rolls <= 6)
		{
			printf("You got this on roll %d!\n", number_rolls + 1);
		}
		else
		{
			printf("Holy cow, %d rolls! Hurry up!\n", number_rolls + 1);
		}
		break;

	case 2:
		if (win_loss_neither == 1)
		{
			printf("YOU WON CONGRATS!\n");
		}
		else if (win_loss_neither == 0)
		{
			printf("AW 'CRAPS,' THE HOUSE WINS!\n");
		}
		else if (win_loss_neither == -1)
		{
			printf("Your 'point' is %d! Good Luck!\n", point);
		}
		break;

	case 3:
		printf("Roll %d: %d\n", number_rolls + 1, sum_dice);
		break;

	case 4:
		if (current_bank_balance == initial_bank_balance)
		{
			printf("You're Even!\n");
		}
		else if (current_bank_balance <= initial_bank_balance)
		{
			printf("You're in the red!\n");
		}
		else if (current_bank_balance >= initial_bank_balance)
		{
			printf("You're up right now! Keep it rolling!\n");
		}
	}
}

//int ready_to_play(int play_choice)
//{
//	if (play_choice == 'y' || play_choice == 'Y')
//	{
//		return 1;
//	}
//	else if (play_choice == 'n' || play_choice == 'N')
//	{
//		return 0;
//	}
//}

//void resultChatter(int winLossNeither, int point)
//{
//	if (winLossNeither == 1)
//	{
//			printf("YOU WON CONGRATS!\n");
//	}
//	else if (winLossNeither == 0)
//	{
//		printf("AW 'CRAPS,' THE HOUSE WINS!\n");
//	}
//	else if (winLossNeither == -1)
//	{
//		printf("Your 'point' is %d! Good Luck!\n", point);
//	}
//}
//
//void printRollResult(int sum_dice, int number_rolls)
//{
//	printf("Roll %d: %d\n", number_rolls + 1, sum_dice);
//}
//
//
//
