#include "functions.h"

int main(void)
{
	int option = 0, die1_value = 0, die2_value = 0, sum_dice = 0, point_value = 0, win_lose_neither = 0, number_rolls = 0, is_wager_valid = 0, add_or_subtract = 0, choice = 0;
	double wager = 0.0, initial_bank_balance = 0.0, current_bank_balance = 0.0;
	char play_choice = 'n';

	do 
	{
		printf("1. Display Rules\n2. Play Game\n3. Exit\n"); //display menu function goes here
		scanf("%d", &option);
	} while (option < 1 || option >3);

	switch (option)
	{
	case 1: print_game_rules();
		break;
	case 2: printf("Playing Game\n");
		initial_bank_balance = get_bank_balance();

		current_bank_balance = initial_bank_balance;

		while (current_bank_balance > 0)
		{
			printf("Ready to Play? (Y/N): \n");
			scanf(" %c", &play_choice);

			printf("%.2lf\n", current_bank_balance);

			if (play_choice == 'y' || play_choice == 'Y')
			{

				wager = get_wager_amount();

				number_rolls = 0;

				is_wager_valid = checkWagerAmount(wager, current_bank_balance);

				if (is_wager_valid == 1)
				{
					die1_value = roll_die();

					die2_value = roll_die();

					sum_dice = calculate_sum_dice(die1_value, die2_value);

					point_value = sum_dice;

					chatter_messages(1, number_rolls, initial_bank_balance, current_bank_balance, sum_dice, win_lose_neither, point_value);
					chatter_messages(3, number_rolls, initial_bank_balance, current_bank_balance, sum_dice, win_lose_neither, point_value);
					
					win_lose_neither = is_win_loss_or_point(sum_dice);

					if (win_lose_neither == 1)
					{
						/*chatter_messages(1, number_rolls, initial_bank_balance, current_bank_balance, sum_dice, win_lose_neither, point_value);*/
						add_or_subtract = 1;
						current_bank_balance = adjust_bank_balance(current_bank_balance, wager, add_or_subtract);
						chatter_messages(2, number_rolls, initial_bank_balance, current_bank_balance, sum_dice, win_lose_neither, point_value);
					}
					else if (win_lose_neither == 0)
					{
						/*chatter_messages(1, number_rolls, initial_bank_balance, current_bank_balance, sum_dice, win_lose_neither, point_value);*/
						add_or_subtract = 0;
						current_bank_balance = adjust_bank_balance(current_bank_balance, wager, add_or_subtract);
						chatter_messages(2, number_rolls, initial_bank_balance, current_bank_balance, sum_dice, win_lose_neither, point_value);
					}
					else if (win_lose_neither == -1)
					{
						while (win_lose_neither == -1)
						{
							die1_value = roll_die();

							die2_value = roll_die();

							number_rolls += 1;

							sum_dice = calculate_sum_dice(die1_value, die2_value);

							//printRollResult(sum_dice, number_rolls);

							win_lose_neither = is_point_loss_or_neither(sum_dice, point_value);
							chatter_messages(1, number_rolls, initial_bank_balance, current_bank_balance, sum_dice, win_lose_neither, point_value);
							chatter_messages(3, number_rolls, initial_bank_balance, current_bank_balance, sum_dice, win_lose_neither, point_value);
						}
						if (win_lose_neither == 1)
						{
							add_or_subtract = 1;
							current_bank_balance = adjust_bank_balance(current_bank_balance, wager, add_or_subtract);
							chatter_messages(2, number_rolls, initial_bank_balance, current_bank_balance, sum_dice, win_lose_neither, point_value);
						}
						else if (win_lose_neither == 0)
						{
							add_or_subtract = 0;
							current_bank_balance = adjust_bank_balance(current_bank_balance, wager, add_or_subtract);
							chatter_messages(2, number_rolls, initial_bank_balance, current_bank_balance, sum_dice, win_lose_neither, point_value);
						}
					}
				}
				else
				{
					printf("Please enter a new bet!\n");
				}
				chatter_messages(4, number_rolls, initial_bank_balance, current_bank_balance, sum_dice, win_lose_neither, point_value);
			}
			else 
			{
				return 0;
			}
		}
		
		break;
	case 3: printf("Exit\n");
		break;
	default: printf("Invalid Input\n");
		break;
	}

		
	return 0;
}


