/*
Name: Elliot Small
CPT_S 121 Lab Section 5
Professor: Andrew O'Fallon
TA: Dylan Smith
Goal: This program will allow the user to play the dice game "Craps," as well as giving the ability to wager "money" on it
*/


#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#define _CRT_SECURE_NO_WARNINGS

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <time.h>

void print_game_rules(void);

double get_bank_balance(void);

double get_wager_amount(void);

int checkWagerAmount(double wager, double balance);

int roll_die(void);

int calculate_sum_dice(int die1_value, int die2_value);

int is_win_loss_or_point(int sum_dice);

int is_point_loss_or_neither(int sum_dice, int point_value);

double adjust_bank_balance(double bank_balance, double wager_amount, int add_or_subtract);

void chatter_messages(int chatter_type,int number_rolls, double initial_bank_balance, double current_bank_balance, int sum_dice, int win_loss_neither, int point);

//int ready_to_play(int play_choice);

//void resultChatter(int winLossNeither, int point);

//void printRollResult(int sum_dice, int number_rolls);

#endif